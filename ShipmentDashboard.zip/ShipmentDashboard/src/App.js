import React from 'react';
import './App.css';
import Shipment from './shipment';

function App() {
  return (
    <div className="App">
    <div className="header">
    <Shipment/>
    </div>
    </div>
  );
}

export default App;
