import React from 'react';
import { Row, Col, Table, Navbar, Nav } from 'react-bootstrap';
import './shipment.scss';
import axios from 'axios';
import destination from './destination.svg';
import warehouse from './warehouse.svg';
import Data from './data.json';
import logo from './logo.svg';
import FontAwesome from 'react-fontawesome'
import profile from './profile.svg';
import moment from 'moment';


class Shipment extends React.Component {
    constructor() {
        super();
        this.state = {
            responseData: {},
            scanData: []
        }
        this.handleClick = this.handleClick.bind(this);
    }
    handleClick(val) {
        this.setState({
            scanData: val.scan
        })
    }
    getData = () => {
        var self = this;
        var bearerToken = 'tTU3gFVUdP';
        var config = {
            headers: { 'Authorization': "Bearer " + bearerToken }
        };
        var body = { 'email': "mayankmittal@intugine.com" }
        axios.post("https://93870v1pgk.execute-api.ap-south-1.amazonaws.com/latest/shipments/mayank", body, config)
            .then(response => {
                if (response.status === 200) {
                    self.setState({
                        responseData: response.data,
                        scanData: response.data.data[0].scan
                    })
                }
            }).catch(err => {
                console.log(err)
            })
    }
    componentDidMount() {
        this.getData();
    }
    componentDidUpdate() {
        // this.getData();
    }
    render() {
        // console.log(Data.data)
        var self = this;
        var data = [], rowData = [], scanData = [], cardData = {};
        // console.log(this.state.responseData)
        if (self.state.responseData && self.state.responseData.data && self.state.responseData.data[0].extra_fields.expected_delivery_date) {
            data = self.state.responseData.data;
            console.log(data)
            data.forEach((element, i) => {
                if (cardData[element.current_status_code]) {
                    cardData[element.current_status_code]++;
                }
                else {
                    cardData[element.current_status_code] = 1;
                }
                rowData.push(<tr key={i} onClick={(e) => this.handleClick(element)}>
                    <td>{element.awbno}</td>
                    <td>{element.carrier}</td>
                    <td>{element.from}</td>
                    <td>{element.to}</td>
                    <td>{element.carrier}</td>
                    <td>{moment(element.pickup_date, "YYYY-MM-DD HH:mm:SS").format("DD/MM/YYYY")}</td>
                    <td>{
                        element.extra_fields && element.extra_fields.expected_delivery_date &&
                        moment(element.extra_fields.expected_delivery_date, "YYYY-MM-DD HH:mm:SS").format("DD/MM/YYYY")
                    }
                    </td>
                    <td>{element.current_status}</td>
                </tr>)
            });


        }
        var cardRow = []
        Object.keys(cardData).forEach((ele, i) => {
            cardRow.push(<Col key={i} md={1} >
                <div className={`cards${(i === 0) ? ' active' : ''}`}>
                    <h6 className="card-label">{ele}</h6>
                    <h1 className="card-value">{cardData[ele]}</h1>
                </div>
            </Col>)
        })

        if (self.state.scanData) {
            self.state.scanData.forEach((ele, i) => {
                scanData.push(
                    <li key={i}>
                        <FontAwesome className="circle" name="circle"></FontAwesome>
                        <div className="timeline-status">
                            <span className="detail">{ele.status_detail.toLowerCase()}</span>
                            <span className="time">{moment(ele.time, "YYYY-MM-DD HH:mm:SS").format("HH:mm")}</span>
                            <span className="time">{moment(ele.time, "YYYY-MM-DD HH:mm:SS").format("DD-MM-YYYY")}</span>
                        </div>
                    </li>
                )
            });
        }

        return (
            <div className="shipment-container">
                <Navbar className="shipment-header" fixed="top">
                    <Navbar.Brand href="#home"><img src={logo} alt="logo" /><span>Intugine</span></Navbar.Brand>
                    <Nav className="ml-auto">
                        <Nav.Link className="home active" href="#home">Home</Nav.Link>
                        <Nav.Link className="home" href="#features">Brands</Nav.Link>
                        <Nav.Link className="home" href="#pricing">Transporters</Nav.Link>
                        <Nav.Link className="profile"><img src={profile} alt="profile" /></Nav.Link>
                        <Nav.Link><FontAwesome name="chevron-down"></FontAwesome></Nav.Link>
                    </Nav>
                </Navbar>
                <Row className="justify-content-md-center shipment-row">
                    {cardRow}
                </Row>
                <Row className="second-row">
                    <Col md={4}>
                        <div className="timeline-card">
                            <ul className="timeline-list">
                                <li><div className="destination">
                                    <img src={destination} alt="destination" />
                                </div>
                                </li>
                                {
                                    scanData
                                }
                                <li> <div className="warehouse">
                                    <img src={warehouse} alt="warehouse" />
                                </div>
                                </li>
                            </ul>

                        </div>
                    </Col>
                    <Col md={8} className="table-col">
                        <Table striped hover responsive>
                            <thead>
                                <tr>
                                    <th>AWB Number</th>
                                    <th>Transporter</th>
                                    <th>Source</th>
                                    <th>Destination</th>
                                    <th>Brand</th>
                                    <th>Start Date</th>
                                    <th>ETD</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {rowData}
                            </tbody>
                        </Table>
                    </Col>
                </Row>
            </div>
        )

    }
}
export default Shipment